/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package impl;

import adt.Set;
import java.util.Arrays;

/**
 *
 * @author As
 * @param <T> make the code work for every type of an object
 */
public class LLQHashTableSet<T> implements Set<T> {

    private LinkedListQueue<T>[] backets;
    private int size;
    
    public LLQHashTableSet() {
        backets = (LinkedListQueue<T>[]) new LinkedListQueue[10];
        size = 0;
        
    }

    @Override
    public void add(T value) {
        if (!contains(value)) {
            int hash = value.hashCode();
            if (hash >= 0) {
                hash = hash % 10;

            } else if (hash < 0) {
                hash = -hash % 10;
            }
            if (hash == 0) {
                if (backets[0] == null) {
                    backets[0] = new LinkedListQueue();
                    backets[0].enqueue(value);
                    size++;
                } else {
                    backets[0].enqueue(value);
                    size++;
                }
            } else if (hash == 1) {
                if (backets[1] == null) {
                    backets[1] = new LinkedListQueue();
                    backets[1].enqueue(value);
                    size++;
                } else {
                    backets[1].enqueue(value);
                    size++;
                }
            } else if (hash == 2) {
                if (backets[2] == null) {
                    backets[2] = new LinkedListQueue();
                    backets[2].enqueue(value);
                    size++;
                } else {
                    backets[2].enqueue(value);
                    size++;
                }
            } else if (hash == 3) {
                if (backets[3] == null) {
                    backets[3] = new LinkedListQueue();
                    backets[3].enqueue(value);
                    size++;
                } else {
                    backets[3].enqueue(value);
                    size++;
                }
            } else if (hash == 4) {
                if (backets[4] == null) {
                    backets[4] = new LinkedListQueue();
                    backets[4].enqueue(value);
                    size++;
                } else {
                    backets[4].enqueue(value);
                    size++;
                }
            } else if (hash == 5) {
                if (backets[5] == null) {
                    backets[5] = new LinkedListQueue();
                    backets[5].enqueue(value);
                    size++;
                } else {
                    backets[5].enqueue(value);
                    size++;
                }
            } else if (hash == 6) {
                if (backets[6] == null) {
                    backets[6] = new LinkedListQueue();
                    backets[6].enqueue(value);
                    size++;
                } else {
                    backets[6].enqueue(value);
                    size++;
                }
            } else if (hash == 7) {
                if (backets[7] == null) {
                    backets[7] = new LinkedListQueue();
                    backets[7].enqueue(value);
                    size++;
                } else {
                    backets[7].enqueue(value);
                    size++;
                }
            } else if (hash == 8) {
                if (backets[8] == null) {
                    backets[8] = new LinkedListQueue();
                    backets[8].enqueue(value);
                    size++;
                } else {
                    backets[8].enqueue(value);
                    size++;
                }
            } else if (hash == 9) {
                if (backets[9] == null) {
                    backets[9] = new LinkedListQueue();
                    backets[9].enqueue(value);
                    size++;
                } else {
                    backets[9].enqueue(value);
                    size++;
                }
            }
        }
    }

    @Override
    public boolean contains(T value) {
        int hash = value.hashCode();
        boolean result = false;
        if (hash >= 0) {
            hash = hash % 10;
        } else if (hash < 0) {
            hash = -hash % 10;
        }
        if (size == 0) {
            return false;
        }
        if (hash == 0) {
            if (backets[0] == null) {
                return false;
            }
            int size0 = backets[0].getSize();
            for (int i = 0; i < size0; i++) {
                try {
                    T val = backets[0].dequeue();
                    backets[0].enqueue(val);
                    if (val.equals(value)) {
                        return true;
                    }
                } catch (Exception ex) { //This should not happen
                }
            }
        } else if (hash == 1) {
            if (backets[1] == null) {
                return false;
            }
            int size1 = backets[1].getSize();
            for (int i = 0; i < size1; i++) {
                try {
                    T val = backets[1].dequeue();
                    backets[1].enqueue(val);
                    if (val.equals(value)) {
                        return true;
                    }
                } catch (Exception ex) { //This should not happen
                }
            }
            return false;
        } else if (hash == 2) {
            if (backets[2] == null) {
                return false;
            }
            int size2 = backets[2].getSize();
            for (int i = 0; i < size2; i++) {
                try {
                    T val = backets[2].dequeue();
                    backets[2].enqueue(val);
                    if (val.equals(value)) {
                        return true;
                    }
                } catch (Exception ex) { //This should not happen
                }
            }
        } else if (hash == 3) {
            if (backets[3] == null) {
                return false;
            }
            int size3 = backets[3].getSize();
            for (int i = 0; i < size3; i++) {
                try {
                    T val = backets[3].dequeue();
                    backets[3].enqueue(val);
                    if (val.equals(value)) {
                        return true;
                    }
                } catch (Exception ex) { //This should not happen
                }
            }
        } else if (hash == 4) {
            if (backets[4] == null) {
                return false;
            }
            int size4 = backets[4].getSize();
            for (int i = 0; i < size4; i++) {
                try {
                    T val = backets[4].dequeue();
                    backets[4].enqueue(val);
                    if (val.equals(value)) {
                        return true;
                    }
                } catch (Exception ex) { //This should not happen
                }
            }
        } else if (hash == 5) {
            if (backets[5] == null) {
                return false;
            }
            int size5 = backets[5].getSize();
            for (int i = 0; i < size5; i++) {
                try {
                    T val = backets[5].dequeue();
                    backets[5].enqueue(val);
                    if (val.equals(value)) {
                        return true;
                    }
                } catch (Exception ex) { //This should not happen
                }
            }
        } else if (hash == 6) {
            if (backets[6] == null) {
                return false;
            }
            int size6 = backets[6].getSize();
            for (int i = 0; i < size6; i++) {
                try {
                    T val = backets[6].dequeue();
                    backets[6].enqueue(val);
                    if (val.equals(value)) {
                        return true;
                    }
                } catch (Exception ex) { //This should not happen
                }
            }
        } else if (hash == 7) {
            if (backets[7] == null) {
                return false;
            }
            int size7 = backets[7].getSize();
            for (int i = 0; i < size7; i++) {
                try {
                    T val = backets[7].dequeue();
                    backets[7].enqueue(val);
                    if (val.equals(value)) {
                        return true;
                    }
                } catch (Exception ex) { //This should not happen
                }
            }
        } else if (hash == 8) {
            if (backets[8] == null) {
                return false;
            }
            int size8 = backets[8].getSize();
            for (int i = 0; i < size8; i++) {
                try {
                    T val = backets[8].dequeue();
                    backets[8].enqueue(val);
                    if (val.equals(value)) {
                        return true;
                    }
                } catch (Exception ex) { //This should not happen
                }
            }
        } else if (hash == 9) {
            if (backets[9] == null) {
                return false;
            }
            int size9 = backets[9].getSize();
            for (int i = 0; i < size9; i++) {
                try {
                    T val = backets[9].dequeue();
                    backets[9].enqueue(val);
                    if (val.equals(value)) {
                        return true;
                    }
                } catch (Exception ex) { //This should not happen
                }
            }
        }
        return false;
    }

    @Override
    public boolean remove(T value) {
        if (contains(value)) {
            int hash = value.hashCode();
            if (hash >= 0) {
                hash = hash % 10;
            } else if (hash < 0) {
                hash = -hash % 10;
            }
            switch (hash) {
                case 0:
                    int size0 = backets[0].getSize();
                    for (int i = 0; i < size0; i++) {
                        try {
                            T val = backets[0].dequeue();
                            if (val.equals(value)) {
                                size--;
                                return true;
                            } else {
                                backets[0].enqueue(val);
                            }
                        } catch (Exception ex) { //This should not happen
                        }
                    }

                case 1:
                    int size1 = backets[1].getSize();
                    for (int i = 0; i < size1; i++) {
                        try {
                            T val = backets[1].dequeue();
                            if (val.equals(value)) {
                                size--;
                                return true;
                            } else {
                                backets[1].enqueue(val);
                            }
                        } catch (Exception ex) { //This should not happen
                        }
                    }
                case 2:
                    int size2 = backets[2].getSize();
                    for (int i = 0; i < size2; i++) {
                        try {
                            T val = backets[2].dequeue();
                            if (val.equals(value)) {
                                size--;
                                return true;
                            } else {
                                backets[2].enqueue(val);
                            }
                        } catch (Exception ex) { //This should not happen
                        }
                    }
                case 3:
                    int size3 = backets[3].getSize();
                    for (int i = 0; i < size3; i++) {
                        try {
                            T val = backets[3].dequeue();
                            if (val.equals(value)) {
                                size--;
                                return true;
                            } else {
                                backets[3].enqueue(val);
                            }
                        } catch (Exception ex) { //This should not happen
                        }
                    }
                case 4:
                    int size4 = backets[4].getSize();
                    for (int i = 0; i < size4; i++) {
                        try {
                            T val = backets[4].dequeue();
                            if (val.equals(value)) {
                                size--;
                                return true;
                            } else {
                                backets[4].enqueue(val);
                            }
                        } catch (Exception ex) { //This should not happen
                        }
                    }
                case 5:
                    int size5 = backets[5].getSize();
                    for (int i = 0; i < size5; i++) {
                        try {
                            T val = backets[5].dequeue();
                            if (val.equals(value)) {
                                size--;
                                return true;
                            } else {
                                backets[5].enqueue(val);
                            }
                        } catch (Exception ex) { //This should not happen
                        }
                    }
                case 6:
                    int size6 = backets[6].getSize();
                    for (int i = 0; i < size6; i++) {
                        try {
                            T val = backets[6].dequeue();
                            if (val.equals(value)) {
                                size--;
                                return true;
                            } else {
                                backets[6].enqueue(val);
                            }
                        } catch (Exception ex) { //This should not happen
                        }
                    }
                case 7:
                    int size7 = backets[7].getSize();
                    for (int i = 0; i < size7; i++) {
                        try {
                            T val = backets[7].dequeue();
                            if (val.equals(value)) {
                                size--;
                                return true;
                            } else {
                                backets[7].enqueue(val);
                            }
                        } catch (Exception ex) { //This should not happen
                        }
                    }
                case 8:
                    int size8 = backets[8].getSize();
                    for (int i = 0; i < size8; i++) {
                        try {
                            T val = backets[8].dequeue();
                            if (val.equals(value)) {
                                size--;
                                return true;
                            } else {
                                backets[8].enqueue(val);
                            }
                        } catch (Exception ex) { //This should not happen
                        }
                    }
                case 9:
                    int size9 = backets[9].getSize();
                    for (int i = 0; i < size9; i++) {
                        try {
                            T val = backets[9].dequeue();
                            if (val.equals(value)) {
                                size--;
                                return true;
                            } else {
                                backets[9].enqueue(val);
                            }
                        } catch (Exception ex) { //This should not happen
                        }
                    }
            }
        }
        return false;
    }

    @Override
    public T removeAny() throws Exception {
        if (size == 0) {
            throw new Exception("The LLQHashTableSet is empty.");
        } else {
            if (backets[0].getSize() != 0) {
                size--;
                return backets[0].dequeue();
            } else if (backets[1].getSize() != 0) {
                size--;
                return backets[1].dequeue();
            } else if (backets[2].getSize() != 0) {
                size--;
                return backets[2].dequeue();
            } else if (backets[3].getSize() != 0) {
                size--;
                return backets[3].dequeue();
            } else if (backets[4].getSize() != 0) {
                size--;
                return backets[4].dequeue();
            } else if (backets[5].getSize() != 0) {
                size--;
                return backets[5].dequeue();
            } else if (backets[6].getSize() != 0) {
                size--;
                return backets[6].dequeue();
            } else if (backets[7].getSize() != 0) {
                size--;
                return backets[7].dequeue();
            } else if (backets[8].getSize() != 0) {
                size--;
                return backets[8].dequeue();
            } else {
                size--;
                return backets[9].dequeue();
            }
        }
    }

    @Override
    public int getSize() {
        return size;
    }

    @Override
    public void clear() {
        backets = (LinkedListQueue<T>[]) new LinkedListQueue[10];
        size = 0;
    }

      @Override
    public String toString() {
        String result=null;
        for(int i=0; i<10; i++){
              result+=  backets[i] + "\n";
            }
        result+="Size:" +  size;
        return result;
    }

}
