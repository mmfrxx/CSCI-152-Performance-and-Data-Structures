/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package impl;

import adt.Set;

/**
 *
 * @author As
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Set<Integer> hashash = new LLQHashTableSet();
        try {
            hashash.removeAny();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        System.out.println(hashash);

        for (int i = 1; i < 21; i++) {
            hashash.add(i);
        }
        System.out.println(hashash);
        for (int i = 2; i < 21; i = i + 2) {
            hashash.remove(i);
        }
        System.out.println(hashash);
        System.out.println(hashash.remove(10));
        System.out.println(hashash.remove(100));
        System.out.println(hashash);
        
        for (int i = 1; i < 31; i++) {
            hashash.add(i);
        }
        System.out.println(hashash);
        
        for(int i =0; i<10; i++){
         try {
            System.out.println(hashash.removeAny());
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }}
        System.out.println(hashash);
        
        hashash.clear();
        System.out.println(hashash);
        
        for(int i=51;i<80;i=i+2){
            hashash.add(i);
        }
         System.out.println(hashash);
    }

}
