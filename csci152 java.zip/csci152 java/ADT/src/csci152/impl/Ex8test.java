/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csci152.impl;

import csci152.adt.IntQueue;

/**
 *
 * @author As
 */
public class Ex8test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)  {
        int i =0;
        int k =1, size = 12;
        
        ArrayIntStack stk = new ArrayIntStack();
        try{
            stk.pop();
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
        
        
          for (;i<size; i++){
              stk.push(k);
              k++;
          }
            
         
          System.out.println(stk);
          System.out.println(stk.getSize());
          
          try{
            System.out.println(stk.pop());
          }catch(Exception ex){
            System.out.println(ex.getMessage());
          }
          
         
           
           try{
            System.out.println(stk.pop());
          }catch(Exception ex){
            System.out.println(ex.getMessage());
          }
          
          try{
            System.out.println(stk.pop());
          }catch(Exception ex){
            System.out.println(ex.getMessage());
          }
          try{
            System.out.println(stk.pop());
          }catch(Exception ex){
            System.out.println(ex.getMessage());
          }
          try{
            System.out.println(stk.pop());
          }catch(Exception ex){
            System.out.println(ex.getMessage());
          }
          System.out.println(stk);
          System.out.println(stk.getSize());
          
          
          stk.clear();
          System.out.println(stk);
          System.out.println(stk.getSize());
          
          k = 0;
          for ( i = 0 ;i<22; i++){
              stk.push(k);
              k++;
          }
            
         
          System.out.println(stk);
          System.out.println(stk.getSize());
          
          IntQueue queue = new ArrayIntQueue();
          k = 1;
          try{
           queue.dequeue();
          }catch(Exception ex){
          System.out.println(ex.getMessage());
          }
     
          for ( i = 0;i<8; i++){
              queue.enqueue(k);
              k++;
          }
            
         
          System.out.println(queue);
          System.out.println(queue.getSize());
          
          
          try {
            System. out.println("\n"+queue.dequeue());
           } catch (Exception ex) {   
          }
           try {
            System. out.println("\n"+queue.dequeue());
          } catch (Exception ex) {   
          }try {
            System. out.println("\n"+queue.dequeue());
          } catch (Exception ex) {   
          }
          
        
          System.out.println(queue);
          System.out.println(queue.getSize());
          
          for(i = 0; i <=9; i++){
               queue.enqueue(k);
               k++;
               queue.enqueue(k);
               k++;
          try {
            System. out.println("\nnumber"+queue.dequeue());
          } catch (Exception ex) {   
          }
          try {
            System. out.println("\nnumber"+queue.dequeue());
          } catch (Exception ex) {   
          }
          System.out.println(queue);
          System.out.println("Size is " + queue.getSize());
          
          }
         
          queue.clear();
          System.out.println(queue);
          System.out.println("Size is " + queue.getSize());
          
          k = 1;
          for ( i = 0;i<22; i++){
              queue.enqueue(k);
              k++;
          }
            
         
          System.out.println(queue);
          System.out.println(queue.getSize());
          
}
}
