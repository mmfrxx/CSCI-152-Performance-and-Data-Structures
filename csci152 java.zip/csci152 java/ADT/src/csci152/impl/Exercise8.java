/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csci152.impl;
import csci152.adt.IntQueue;
import csci152.adt.IntStack;


/**
 *
 * @author As
 */
public class Exercise8<T> {
    private int size;
    public Exercise8(){
        size = 0;
        
    }
            
     public static IntStack copyStack(IntStack orig){
         ArrayIntStack fakereverse = new ArrayIntStack();
         ArrayIntStack fake = new ArrayIntStack();
        int size;
         size = orig.getSize();
        
         
for(int i = 0; i <size; i++){
            try{
                fakereverse.push(orig.pop());
            }catch( Exception ex){
                System.out.println(ex.getMessage());
            }
           }
         
         for(int i = 0;i < size; i++){
            try{
                fake.push(fakereverse.pop());
            }catch( Exception ex){
                System.out.println(ex.getMessage());
            }
           }
        return fake;
        
          }
     
     public static IntQueue copyQueue(IntQueue orig){
         ArrayIntQueue que = new ArrayIntQueue();
         int size;
         size = orig.getSize();
         for(int i = 0;i < size; i++){
            try{
                que.enqueue(orig.dequeue());
            }catch( Exception ex){
                System.out.println(ex.getMessage());
            }
           }
        return que;
         
     }
     
     public static void insert(IntStack st, int pos, int val){
     
         
         ArrayIntStack fakereverse = new ArrayIntStack();
         ArrayIntStack fake = new ArrayIntStack();
        int size;
         size = st.getSize();
        
         
for(int i = 0; i <size; i++){
           try{
                fakereverse.push(st.pop());
            }catch( Exception ex){
                System.out.println(ex.getMessage());
            }
           }
         
         for(int i = 0;i < size/*I used here "size -1" because I will use fakereverse in just 
                 if but not else if therefore at the end the size of fakereverse would be -*/; i++){
            if(i ==pos){
                st.push(val);
               
          
            }
                try{
                st.push(fakereverse.pop());
            }catch( Exception ex){
                System.out.println(ex.getMessage());
            }
            }
             }
          
          public static void reverseQueue(IntQueue toRev) {
              ArrayIntStack st = new ArrayIntStack();
              int size, i;
              size = toRev.getSize();
              
              for( i = 0; i <size; i++){
                 try{
                st.push(toRev.dequeue());
                 }catch( Exception ex){
                System.out.println(ex.getMessage());
                 } 
              }
                toRev.clear();
                 for( i =0; i < size; i++){
                 try{
                  
                toRev.enqueue(st.pop());
                 }catch( Exception ex){
                System.out.println(ex.getMessage());
                 } 
                 
                 
              }
          }
}
     
          
     
  

