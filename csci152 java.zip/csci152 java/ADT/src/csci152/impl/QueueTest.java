/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csci152.impl;

import csci152.adt.IntQueue;

/**
 *
 * @author As
 */
public class QueueTest {
    public static void main(String[]args){
    IntQueue queue = new ArrayIntQueue();
     int k =1, size = 8;
     
     try{
     queue.dequeue();
}catch(Exception ex){
    System.out.println(ex.getMessage());
}
     k =0;
      for (int i = 0;i<size; i++){
              queue.enqueue(k);
              k++;
          }
            
         
          System.out.println(queue);
          System.out.println(queue.getSize());
}
}