/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfinal;

import adt.Stack;
import impl.LinkedListStack;
import impl.TreeNode;

/**
 *
 * @author As
 */
public class Final {

    /**
     * @param args the command line arguments
     */
 public static int height(TreeNode<Integer> node) { 
if (node == null) return 0; 
int hleft = 1+height(node.getLeft()); 
int hright = 1+height(node.getRight()); 
if (hleft > hright) { 
return hleft; 
} else { 
return hright; 
} 
}
   public static void main(String[]args){
      TreeNode<Integer> intr = new TreeNode(3);
      intr.setLeft(new TreeNode(8));
      intr.setRight(new TreeNode(6));
      intr.getLeft().setLeft(new TreeNode(5));
      intr.getLeft().setRight(new TreeNode(7));
      intr.getRight().setLeft(new TreeNode(11));
       intr.getRight().getLeft().setLeft(new TreeNode(11));
              intr.getRight().setRight(new TreeNode(2));
             System.out.println( height(intr));
              
   }
}
