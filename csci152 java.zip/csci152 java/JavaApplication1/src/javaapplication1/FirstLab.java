/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author As
 */
public class FirstLab {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
   int l,w,h,volume, surfacearea;
   double r=100, circ,area;
   l=10;
   w=10;
   h=10;
   volume = l*w*h;
   surfacearea= 2 * (l*w+w*h+h*l);
   circ = 2*3.14*r;
   area = 3.14*r*r;
   System.out.println("The volume of the cube is "+ volume+ " and the surface area is "
           + "equal to " + surfacearea+"." );
   
   System.out.println("The circumference and the area of the circle are equal to " + circ
           + " " +area+ " reaspectively.\n\n\n\n\n\n");
   System.out.println("_________________________");
   System.out.println("\\_______________________/");
   System.out.println(" |____|_____|_____|____|");
   System.out.println(" |___|_____|_|_____|___|");
   System.out.println(" |__|_|||||_|_|||||_|__|");
   System.out.println(" |____|||||___|||||____|");
   System.out.println(" |__|____|_____|____|__|");
   System.out.println(" |____|_____|_____|____|");
   System.out.println("/_______________________\\");
}
}

